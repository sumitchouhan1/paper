package service;

import java.util.Map;

import DAO.IProduct;
import DAO.IProduct_Impl;
import DAO.ProductException;

public class IProductService_Impl implements IService{
IProduct daoref;
	public IProductService_Impl() {
	daoref=new IProduct_Impl();
}
	@Override
	public int updateProducts(String category, int hike)throws ProductException {
		// TODO Auto-generated method stub
		return daoref.updateProducts(category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails()throws ProductException {
		// TODO Auto-generated method stub
		return daoref.getProductDetails();
	}
	
	

}
