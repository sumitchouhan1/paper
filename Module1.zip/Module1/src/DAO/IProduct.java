package DAO;
import java.util.Map;

public interface IProduct {

	public int updateProducts(String category,int hike)throws ProductException;
	public Map<String,Integer> getProductDetails()throws ProductException;

}
